import { Injectable } from '@angular/core';
@Injectable({
  providedIn: 'root'
})
export class HelperService {


  constructor() { }

  navigateToHistoryBack() {
    window.history.back();
  }

  numberOnly(event): boolean {
    if (event && event.target) {
      const value = event.target.value;
      const charCode = (event.which) ? event.which : event.keyCode;
      if (charCode === 46 && value.split('.').length > 1) {
        return false;
      }
      if (charCode === 46 && (value.split('.').length <= 1)) {
        return true;
      }
      if (charCode > 31 && (charCode < 48 || charCode > 57)) {
        return false;
      }
      if (value && Number(value) === 0) {
        return false;
      }
      return true;
    }
  }
}
